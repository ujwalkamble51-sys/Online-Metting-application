import express from "express";
import path from "path";
import { createServer as createViteServer } from "vite";
import { GoogleGenAI } from "@google/genai";
import dotenv from "dotenv";

dotenv.config();

const app = express();
const PORT = 3000;

// Initialize GoogleGenAI with guidelines
let ai: GoogleGenAI | null = null;
if (process.env.GEMINI_API_KEY) {
  ai = new GoogleGenAI({
    apiKey: process.env.GEMINI_API_KEY,
    httpOptions: {
      headers: {
        "User-Agent": "aistudio-build",
      },
    },
  });
} else {
  console.warn("Warning: GEMINI_API_KEY is not defined. AI summaries will fall back to local mock summaries.");
}

app.use(express.json());

// In-memory data store
interface Participant {
  peerId: string;
  name: string;
  joinedAt: number;
  lastSeen: number;
  isMuted: boolean;
  isCamOff: boolean;
  isScreenSharing: boolean;
  isHandRaised: boolean;
}

interface Message {
  id: string;
  senderId: string;
  senderName: string;
  text: string;
  timestamp: number;
  isSystem: boolean;
}

interface Signal {
  senderId: string;
  type: "offer" | "answer" | "candidate";
  data: any;
}

interface Room {
  id: string;
  participants: Map<string, Participant>;
  messages: Message[];
  signals: Map<string, Signal[]>; // targetPeerId -> signals
}

const rooms = new Map<string, Room>();

// Helper to generate Google Meet-style IDs: abc-defg-hij
function generateMeetingCode(): string {
  const part1 = Math.random().toString(36).substring(2, 5);
  const part2 = Math.random().toString(36).substring(2, 6);
  const part3 = Math.random().toString(36).substring(2, 5);
  return `${part1}-${part2}-${part3}`;
}

// Check and prune stale users (no heartbeat for >10 seconds)
function pruneStaleParticipants(room: Room): boolean {
  let changed = false;
  const now = Date.now();
  for (const [peerId, p] of room.participants.entries()) {
    // If last heartbeat was more than 10 seconds ago, prune
    if (now - p.lastSeen > 10000) {
      room.participants.delete(peerId);
      room.signals.delete(peerId);
      
      // Post system message about leaving
      room.messages.push({
        id: Math.random().toString(36).substring(2, 11),
        senderId: "system",
        senderName: "System",
        text: `${p.name} disconnected (timeout)`,
        timestamp: now,
        isSystem: true,
      });
      changed = true;
    }
  }
  return changed;
}

// API Routes
// 1. Create a room
app.post("/api/rooms", (req, res) => {
  const { code } = req.body;
  const roomId = code ? code.trim().toLowerCase() : generateMeetingCode();
  
  if (!rooms.has(roomId)) {
    rooms.set(roomId, {
      id: roomId,
      participants: new Map(),
      messages: [
        {
          id: "sys-init",
          senderId: "system",
          senderName: "System",
          text: `Meeting room constructed: ${roomId}`,
          timestamp: Date.now(),
          isSystem: true,
        }
      ],
      signals: new Map(),
    });
  }
  
  res.json({ roomId });
});

// 2. Join room
app.post("/api/rooms/:roomId/join", (req, res) => {
  const { roomId } = req.params;
  const { peerId, name, isMuted, isCamOff } = req.body;
  
  let room = rooms.get(roomId);
  if (!room) {
    // Create dynamically on the fly if needed
    room = {
      id: roomId,
      participants: new Map(),
      messages: [
        {
          id: "sys-init",
          senderId: "system",
          senderName: "System",
          text: `Meeting room joined: ${roomId}`,
          timestamp: Date.now(),
          isSystem: true,
        }
      ],
      signals: new Map(),
    };
    rooms.set(roomId, room);
  }
  
  const now = Date.now();
  const participant: Participant = {
    peerId,
    name,
    joinedAt: now,
    lastSeen: now,
    isMuted: !!isMuted,
    isCamOff: !!isCamOff,
    isScreenSharing: false,
    isHandRaised: false,
  };
  
  room.participants.set(peerId, participant);
  
  // Add join system message
  room.messages.push({
    id: Math.random().toString(36).substring(2, 11),
    senderId: "system",
    senderName: "System",
    text: `${name} joined the meeting.`,
    timestamp: now,
    isSystem: true,
  });
  
  res.json({
    success: true,
    participants: Array.from(room.participants.values()),
  });
});

// 3. Leave room
app.post("/api/rooms/:roomId/leave", (req, res) => {
  const { roomId } = req.params;
  const { peerId } = req.body;
  
  const room = rooms.get(roomId);
  if (room) {
    const p = room.participants.get(peerId);
    if (p) {
      room.participants.delete(peerId);
      room.signals.delete(peerId);
      
      room.messages.push({
        id: Math.random().toString(36).substring(2, 11),
        senderId: "system",
        senderName: "System",
        text: `${p.name} left the meeting.`,
        timestamp: Date.now(),
        isSystem: true,
      });
    }
  }
  res.json({ success: true });
});

// 4. Sync client audio/cam/screen toggles
app.post("/api/rooms/:roomId/sync-state", (req, res) => {
  const { roomId } = req.params;
  const { peerId, isMuted, isCamOff, isScreenSharing, isHandRaised } = req.body;
  
  const room = rooms.get(roomId);
  if (room) {
    const p = room.participants.get(peerId);
    if (p) {
      p.lastSeen = Date.now();
      if (isMuted !== undefined) p.isMuted = isMuted;
      if (isCamOff !== undefined) p.isCamOff = isCamOff;
      if (isScreenSharing !== undefined) p.isScreenSharing = isScreenSharing;
      if (isHandRaised !== undefined) p.isHandRaised = isHandRaised;
      
      res.json({ success: true });
      return;
    }
  }
  res.status(404).json({ error: "Participant or room not found" });
});

// 5. Polling endpoint for room state, signals and chat messages
app.get("/api/rooms/:roomId/state", (req, res) => {
  const { roomId } = req.params;
  const { peerId } = req.query as { peerId: string };
  
  const room = rooms.get(roomId);
  if (!room) {
    return res.status(404).json({ error: "Room not found" });
  }
  
  const p = room.participants.get(peerId);
  if (p) {
    p.lastSeen = Date.now();
  }
  
  // Clean up other disconnected peers in room
  pruneStaleParticipants(room);
  
  // Get and clear signals for this viewer
  const pendingSignals = room.signals.get(peerId) || [];
  room.signals.set(peerId, []); // flush
  
  res.json({
    participants: Array.from(room.participants.values()),
    messages: room.messages,
    signals: pendingSignals,
  });
});

// 6. Signal propagation (WebRTC Negotiation exchange)
app.post("/api/rooms/:roomId/signal", (req, res) => {
  const { roomId } = req.params;
  const { senderId, targetId, type, data } = req.body;
  
  const room = rooms.get(roomId);
  if (!room) {
    return res.status(404).json({ error: "Room not found" });
  }
  
  if (!room.signals.has(targetId)) {
    room.signals.set(targetId, []);
  }
  
  room.signals.get(targetId)!.push({
    senderId,
    type,
    data,
  });
  
  res.json({ success: true });
});

// 7. Post user chat message
app.post("/api/rooms/:roomId/message", async (req, res) => {
  const { roomId } = req.params;
  const { senderId, senderName, text } = req.body;
  
  const room = rooms.get(roomId);
  if (!room) {
    return res.status(404).json({ error: "Room not found" });
  }
  
  const message: Message = {
    id: Math.random().toString(36).substring(2, 11),
    senderId,
    senderName,
    text,
    timestamp: Date.now(),
    isSystem: false,
  };
  
  room.messages.push(message);
  
  // AI Co-host feature: if message tags @ai or mentions "gemini", or if it is just a direct message
  const lowerText = text.toLowerCase();
  if (lowerText.includes("@ai") || lowerText.includes("gemini") || lowerText.startsWith("/ai")) {
    const aiPrompt = text.replace(/@ai|\/ai|gemini/gi, "").trim();
    
    // Create a temporary "AI is thinking..." message
    const tempId = "ai-thinking";
    
    const now = Date.now();
    let replyText = "I'm here as your AI meeting assistant. To generate a complete formal summary of our conversation, click the 'AI Summary' button in the chat drawer!";
    
    if (aiPrompt.length > 0 && ai) {
      try {
        const response = await ai.models.generateContent({
          model: "gemini-3.5-flash",
          contents: `You are 'Gemini. AI Meeting Co-host', an active participant in an online video call. A participant named "${senderName}" just sent the following message in the meeting chat: "${aiPrompt}". Keep your response friendly, concise (under 2-3 sentences), structured, and professional. Represent yourself as a participant in the meeting.`,
        });
        if (response.text) {
          replyText = response.text;
        }
      } catch (err: any) {
        console.error("Gemini API Error:", err);
        replyText = `Excuse me, I'm having trouble connecting to my knowledge base right now. (Error: ${err.message || "Unknown error"})`;
      }
    }
    
    room.messages.push({
      id: Math.random().toString(36).substring(2, 11),
      senderId: "gemini-ai",
      senderName: "Gemini (AI Co-host)",
      text: replyText,
      timestamp: Date.now(),
      isSystem: false,
    });
  }
  
  res.json({ success: true });
});

// 8. Meeting Chat Summary using Gemini API
app.post("/api/rooms/:roomId/summarize", async (req, res) => {
  const { roomId } = req.params;
  
  const room = rooms.get(roomId);
  if (!room) {
    return res.status(404).json({ error: "Room not found" });
  }
  
  // Format meeting conversations nicely
  const chatHistory = room.messages
    .filter((m) => !m.isSystem)
    .map((m) => `${m.senderName}: ${m.text}`)
    .join("\n");
    
  if (chatHistory.trim().length === 0) {
    return res.json({
      summary: "### Meeting Summary \nNo conversation transcripts are available yet. Start chatting in the meeting chat box, and I will summarize it for you!",
    });
  }
  
  let summaryText = "";
  if (ai) {
    try {
      const prompt = `You are an expert executive assistant. Review the following transcription notes from a Google Meet video conference chat log:\n\n${chatHistory}\n\nProvide a comprehensive, highly polished meeting summary in markdown:
1. **Meeting Overview & Vibe**: A brief introductory line describing the discussion.
2. **Key Topics Discussed**: Bulleted list of the core topics, questions, or ideas raised.
3. **Decisions or Consensus**: Key alignments, answers, or items agreed upon.
4. **Action Items**: A clear bulleted list of actionable next steps, assigning them to names if mentioned.
Keep your tone warm, highly professional, structured, and helpful.`;

      const response = await ai.models.generateContent({
        model: "gemini-3.5-flash",
        contents: prompt,
      });
      
      summaryText = response.text || "Failed to parse meeting logs.";
    } catch (err: any) {
      console.error("Gemini Summarize Error:", err);
      summaryText = `### AI Summary Generation Failed\n\nUnable to reach Gemini models. (Error: ${err.message || err})`;
    }
  } else {
    // Elegant simulated summary fallback if no API key is set
    summaryText = `### 📋 Meeting Summary (Simulation)
*Note: Using simulated fallback as GEMINI_API_KEY is not defined.*

**1. Overview**
Active collaborative workspace session in meeting room **${roomId}**.

**2. Topics Discussed**
* Connection testing and peer setup.
* Collaboration flow and WebRTC screen sharing performance.
* Real-time text-based chat utility verification.

**3. Action Items**
* Check audio & video devices.
* Share the clean meeting link or code \`${roomId}\` to invite colleagues.
* Use **Raise Hand** feature to orderly handle multi-participant webinars.`;
  }
  
  // Add a nice system message stating a summary was generated
  room.messages.push({
    id: Math.random().toString(36).substring(2, 11),
    senderId: "system",
    senderName: "System",
    text: `✨ Gemini Co-host generated a meeting summary in the sidebar.`,
    timestamp: Date.now(),
    isSystem: true,
  });
  
  res.json({ summary: summaryText });
});

// 9. Send Meeting Invitation via Email address simulation
app.post("/api/rooms/:roomId/invite", (req, res) => {
  const { roomId } = req.params;
  const { email, senderName } = req.body;
  
  const room = rooms.get(roomId);
  if (!room) {
    return res.status(404).json({ error: "Room not found" });
  }
  
  if (!email || !email.includes("@")) {
    return res.status(400).json({ error: "Invalid email address format" });
  }
  
  // Post system message alert confirming email invite dispatch
  const now = Date.now();
  room.messages.push({
    id: Math.random().toString(36).substring(2, 11),
    senderId: "system",
    senderName: "System",
    text: `📧 Meeting invitation successfully dispatched to ${email}`,
    timestamp: now,
    isSystem: true,
  });
  
  console.log(`[SIMULATED EMAIL DELIVERED] To: ${email} | Subject: MeetSphere Meeting Invitation | Body: Join ${senderName}'s online face-to-face conference meeting: ${roomId}.`);
  
  res.json({
    success: true,
    email,
    message: "Invitation sent successfully!"
  });
});

// Serve frontend assets
async function startServer() {
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), "dist");
    app.use(express.static(distPath));
    app.get("*", (req, res) => {
      res.sendFile(path.join(distPath, "index.html"));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Server listening on IP 0.0.0.0, port ${PORT}`);
  });
}

startServer();
