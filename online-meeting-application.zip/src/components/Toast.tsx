import React, { useState, useEffect } from "react";

export interface Toast {
  id: string;
  message: string;
  type?: "info" | "success" | "error";
}

let toastListeners: ((toasts: Toast[]) => void)[] = [];
let toastsList: Toast[] = [];

export function showToast(message: string, type: Toast["type"] = "info") {
  const id = Math.random().toString(36).substring(2, 9);
  const newToast: Toast = { id, message, type };
  toastsList = [...toastsList, newToast];
  
  toastListeners.forEach((listener) => listener(toastsList));
  
  setTimeout(() => {
    toastsList = toastsList.filter((t) => t.id !== id);
    toastListeners.forEach((listener) => listener(toastsList));
  }, 4000);
}

export function ToastContainer() {
  const [toasts, setToasts] = useState<Toast[]>([]);

  useEffect(() => {
    const listener = (newList: Toast[]) => {
      setToasts(newList);
    };
    
    toastListeners.push(listener);
    return () => {
      toastListeners = toastListeners.filter((l) => l !== listener);
    };
  }, []);

  return (
    <div id="toast-container" className="fixed bottom-24 right-6 z-50 flex flex-col space-y-2 pointer-events-none">
      {toasts.map((toast) => (
        <div
          key={toast.id}
          className={`px-4 py-3 rounded-xl shadow-2xl text-xs font-semibold flex items-center gap-2 transform transition-all duration-300 translate-y-0 opacity-100 animate-in slide-in-from-bottom-2 duration-200 pointer-events-auto ${
            toast.type === "success"
              ? "bg-emerald-600 text-white"
              : toast.type === "error"
                ? "bg-rose-600 text-white"
                : "bg-slate-900 border border-slate-800 text-slate-200"
          }`}
        >
          {toast.message}
        </div>
      ))}
    </div>
  );
}
