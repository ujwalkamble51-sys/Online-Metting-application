import React, { useState, useEffect, useRef } from "react";
import { Video, Keyboard, Plus, ArrowRight, Sparkles, Mic, MicOff, VideoOff, Settings, Info } from "lucide-react";
import { createVirtualStream } from "../utils/media-util";

interface LandingPageProps {
  onJoinMeeting: (roomId: string, name: string, isMuted: boolean, isCamOff: boolean) => void;
}

export default function LandingPage({ onJoinMeeting }: LandingPageProps) {
  const [meetingCode, setMeetingCode] = useState("");
  const [displayName, setDisplayName] = useState("");
  const [isMuted, setIsMuted] = useState(false);
  const [isCamOff, setIsCamOff] = useState(false);
  const [localStream, setLocalStream] = useState<MediaStream | null>(null);
  const [isNewMeetingDropdownOpen, setIsNewMeetingDropdownOpen] = useState(false);
  const [createdRoomCode, setCreatedRoomCode] = useState<string | null>(null);
  const [currentTime, setCurrentTime] = useState(new Date());

  const videoRef = useRef<HTMLVideoElement | null>(null);
  const dropdownRef = useRef<HTMLDivElement | null>(null);

  // Update clock every minute
  useEffect(() => {
    const timer = setInterval(() => {
      setCurrentTime(new Date());
    }, 60000);
    return () => clearInterval(timer);
  }, []);

  // Handle outside click to close dropdown
  useEffect(() => {
    function handleClickOutside(event: MouseEvent) {
      if (dropdownRef.current && !dropdownRef.current.contains(event.target as Node)) {
        setIsNewMeetingDropdownOpen(false);
      }
    }
    document.addEventListener("mousedown", handleClickOutside);
    return () => document.removeEventListener("mousedown", handleClickOutside);
  }, []);

  // Set default display name from localStorage if exists
  useEffect(() => {
    const saved = localStorage.getItem("gmeet_name");
    if (saved) {
      setDisplayName(saved);
    } else {
      const gNames = ["Alex Johnson", "Taylor Smith", "Jordan Patel", "Sam Vance", "Morgan Casey"];
      setDisplayName(gNames[Math.floor(Math.random() * gNames.length)]);
    }
  }, []);

  // Save current display name
  const handleNameChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const val = e.target.value;
    setDisplayName(val);
    localStorage.setItem("gmeet_name", val);
  };

  // Local camera stream initialization
  useEffect(() => {
    let activeStream: MediaStream | null = null;

    async function initCamera() {
      if (isCamOff) {
        if (localStream) {
          localStream.getTracks().forEach(t => t.stop());
        }
        setLocalStream(null);
        return;
      }

      try {
        // Attempt real camera media capture
        activeStream = await navigator.mediaDevices.getUserMedia({
          video: { width: 640, height: 480 },
          audio: true
        });
        
        // Ensure audio track matches our initial mute state
        const audioTrack = activeStream.getAudioTracks()[0];
        if (audioTrack) {
          audioTrack.enabled = !isMuted;
        }
      } catch (err) {
        console.warn("Camera access denied or unavailable, using virtual canvas fallback stream:", err);
        // Fallback to high-fidelity virtual canvas stream helper
        activeStream = createVirtualStream(displayName || "User", isMuted);
      }

      setLocalStream(activeStream);
      if (videoRef.current && activeStream) {
        videoRef.current.srcObject = activeStream;
      }
    }

    initCamera();

    return () => {
      if (activeStream) {
        activeStream.getTracks().forEach(track => track.stop());
      }
    };
  }, [isCamOff, displayName]);

  // Adjust audio track enabled property on mute state toggle
  useEffect(() => {
    if (localStream) {
      const audioTrack = localStream.getAudioTracks()[0];
      if (audioTrack) {
        audioTrack.enabled = !isMuted;
      }
    }
  }, [isMuted, localStream]);

  // Quick action: Create dynamic room codes
  const handleCreateMeetingCode = async (instantJoin = false) => {
    try {
      const response = await fetch("/api/rooms", {
        method: "POST",
        headers: { "Content-Type": "application/json" }
      });
      const data = await response.json();
      
      if (instantJoin) {
        onJoinMeeting(data.roomId, displayName || "User", isMuted, isCamOff);
      } else {
        setCreatedRoomCode(data.roomId);
        setIsNewMeetingDropdownOpen(false);
      }
    } catch (e) {
      console.error("Failed to construct a meeting ID", e);
      // Client-side local room fallback code mapping for extreme resiliency
      const generatedCode = Math.random().toString(36).substring(2, 5) + "-" + 
                            Math.random().toString(36).substring(2, 6) + "-" + 
                            Math.random().toString(36).substring(2, 5);
      if (instantJoin) {
        onJoinMeeting(generatedCode, displayName || "User", isMuted, isCamOff);
      } else {
        setCreatedRoomCode(generatedCode);
        setIsNewMeetingDropdownOpen(false);
      }
    }
  };

  const handleJoinByCodeSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!meetingCode.trim()) return;
    
    // Parse meeting code out of URL text if they paste full address path
    let cleanCode = meetingCode.trim();
    if (cleanCode.includes("/meeting/")) {
      cleanCode = cleanCode.split("/meeting/")[1] || cleanCode;
    } else if (cleanCode.includes("/")) {
      const parts = cleanCode.split("/");
      cleanCode = parts[parts.length - 1] || cleanCode;
    }
    
    onJoinMeeting(cleanCode.toLowerCase(), displayName || "User", isMuted, isCamOff);
  };

  // Format time beautifully: HM, e.g. "10:14 PM • Saturday, Jun 21"
  const formattedTime = currentTime.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
  const formattedDate = currentTime.toLocaleDateString([], { weekday: 'short', month: 'short', day: 'numeric' });

  return (
    <div id="landing-page-root" className="min-h-screen bg-slate-950 flex flex-col font-sans select-none">
      {/* Top Header Bar */}
      <header className="px-6 py-4 flex items-center justify-between border-b border-slate-800/60 bg-slate-900/40 backdrop-blur">
        <div className="flex items-center space-x-3">
          <div className="w-10 h-10 rounded-xl bg-indigo-600 flex items-center justify-center shadow-lg shadow-indigo-600/30">
            <Video className="w-5.5 h-5.5 text-white" />
          </div>
          <span className="text-xl font-bold font-display tracking-tight text-white flex items-center gap-2">
            Meet<span className="text-indigo-400 font-light">Sphere</span>
          </span>
          <span className="hidden sm:inline-block px-2.5 py-0.5 rounded-full bg-indigo-950 text-indigo-300 text-xs font-semibold border border-indigo-900/60">
            AI Enhanced
          </span>
        </div>
        
        <div className="flex items-center space-x-6 text-slate-300 font-mono text-sm leading-none">
          <div>{formattedTime}</div>
          <div className="hidden md:block w-1 h-1 rounded-full bg-slate-700"></div>
          <div className="hidden md:block">{formattedDate}</div>
        </div>
      </header>

      {/* Main Container Layout */}
      <main className="flex-1 max-w-7xl w-full mx-auto px-6 md:px-12 flex flex-col lg:flex-row items-center justify-center gap-12 lg:gap-8 py-10">
        {/* Left Side Content - Invitation Card */}
        <div className="flex-1 flex flex-col justify-center space-y-6 max-w-xl text-center lg:text-left">
          <h1 className="text-4xl sm:text-5xl font-extrabold font-display leading-[1.12] text-white tracking-tight">
            Premium video meetings. <br className="hidden sm:block" />
            Now free & smarter.
          </h1>
          <p className="text-slate-400 text-lg leading-relaxed">
            Re-engineered secure peer meetings, featuring spatial visual cards, real-time screen shares, 
            and a built-in <span className="text-indigo-400 font-semibold">Gemini AI assistant</span> to summarize and catalog your meeting insights.
          </p>

          {/* Join Actions Dashboard */}
          <div className="space-y-4 pt-2">
            <div className="flex flex-col sm:flex-row items-center gap-3 justify-center lg:justify-start">
              {/* New Meeting Button (with Dropdown) */}
              <div ref={dropdownRef} className="relative w-full sm:w-auto">
                <button
                  id="new-meeting-btn"
                  onClick={() => setIsNewMeetingDropdownOpen(!isNewMeetingDropdownOpen)}
                  className="w-full sm:w-auto px-6 py-3.5 rounded-xl bg-indigo-600 hover:bg-indigo-500 font-semibold text-white transition duration-200 flex items-center justify-center gap-2.5 shadow-lg shadow-indigo-600/20 active:scale-95 cursor-pointer text-base"
                >
                  <Plus className="w-5 h-5 stroke-[2.5]" />
                  New Meeting
                </button>

                {isNewMeetingDropdownOpen && (
                  <div className="absolute left-0 right-0 sm:right-auto sm:w-80 mt-2 rounded-xl bg-slate-900 border border-slate-800 shadow-xl overflow-hidden z-50 animate-in fade-in slide-in-from-top-3 duration-200">
                    <button
                      onClick={() => handleCreateMeetingCode(false)}
                      className="w-full px-5 py-4 text-left hover:bg-slate-800/80 transition flex items-center gap-3 cursor-pointer text-sm"
                    >
                      <Video className="w-5 h-5 text-indigo-400" />
                      <div>
                        <div className="font-semibold text-white">Create a meeting for later</div>
                        <div className="text-slate-400 text-xs mt-0.5">Generates a link you can bookmark or send</div>
                      </div>
                    </button>
                    <hr className="border-slate-800" />
                    <button
                      id="instant-meeting-btn"
                      onClick={() => handleCreateMeetingCode(true)}
                      className="w-full px-5 py-4 text-left hover:bg-slate-800/80 transition flex items-center gap-3 cursor-pointer text-sm"
                    >
                      <Sparkles className="w-5 h-5 text-indigo-400" />
                      <div>
                        <div className="font-semibold text-white">Start an instant meeting</div>
                        <div className="text-slate-400 text-xs mt-0.5">Jump directly into a room with testing peers</div>
                      </div>
                    </button>
                  </div>
                )}
              </div>

              {/* Enter meeting code form */}
              <form onSubmit={handleJoinByCodeSubmit} className="w-full sm:w-auto flex items-center gap-2">
                <div className="relative flex-1 sm:max-w-64">
                  <span className="absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-500">
                    <Keyboard className="w-5 h-5" />
                  </span>
                  <input
                    id="meeting-code-input"
                    type="text"
                    placeholder="Enter code or link"
                    value={meetingCode}
                    onChange={(e) => setMeetingCode(e.target.value)}
                    className="w-full pl-11 pr-4 py-3.5 rounded-xl bg-slate-900/60 border border-slate-800 text-white placeholder-slate-500 hover:border-slate-700 focus:outline-none focus:border-indigo-500 text-sm transition"
                  />
                </div>
                <button
                  id="join-meeting-btn"
                  type="submit"
                  disabled={!meetingCode.trim()}
                  className="px-5 py-3.5 rounded-xl text-indigo-400 hover:text-white hover:bg-indigo-600/20 disabled:opacity-40 disabled:hover:bg-transparent disabled:hover:text-indigo-400 font-semibold transition flex items-center gap-1.5 text-sm cursor-pointer border border-transparent hover:border-indigo-600/30"
                >
                  Join
                  <ArrowRight className="w-4 h-4" />
                </button>
              </form>
            </div>

            {/* If meeting link generated, show box */}
            {createdRoomCode && (
              <div className="p-4 rounded-xl bg-indigo-950/40 border border-indigo-900/40 text-left flex items-center justify-between animate-in zoom-in-95 duration-200">
                <div className="truncate pr-4">
                  <div className="text-slate-400 text-xs font-semibold uppercase tracking-wider">Here is your meeting code</div>
                  <div className="text-indigo-300 text-base font-mono font-semibold truncate mt-1">
                    {createdRoomCode}
                  </div>
                </div>
                <button
                  onClick={() => {
                    setMeetingCode(createdRoomCode);
                    setCreatedRoomCode(null);
                  }}
                  className="px-4 py-2 bg-indigo-600 hover:bg-indigo-500 text-white font-semibold text-xs rounded-lg transition"
                >
                  Use now
                </button>
              </div>
            )}
          </div>

          <hr className="border-slate-800" />
          
          <div className="flex items-center gap-2 text-slate-500 text-xs justify-center lg:justify-start font-medium leading-none">
            <Info className="w-4 h-4" />
            <span>Fully persistent, secure, zero cookie payloads needed.</span>
          </div>
        </div>

        {/* Right Side Content - Modern Devices Greenroom Setup */}
        <div className="w-full max-w-lg bg-slate-900/60 border border-slate-800 rounded-2xl p-6 shadow-2xl relative">
          <div className="absolute -top-3 left-6 px-3 py-1 rounded-full bg-slate-800 border border-slate-700 text-slate-400 text-xs font-semibold uppercase tracking-wider">
            Greenroom Preview
          </div>

          {/* Camera display or disabled shroud */}
          <div className="aspect-video w-full rounded-xl bg-slate-950/80 border border-slate-800 overflow-hidden relative flex items-center justify-center shadow-inner group">
            {isCamOff ? (
              <div className="flex flex-col items-center justify-center space-y-3">
                <div className="w-16 h-16 rounded-full bg-slate-800 flex items-center justify-center border border-slate-700 shadow-md">
                  <span className="text-2xl font-bold uppercase text-slate-300">
                    {displayName ? displayName.substring(0, 2) : "ME"}
                  </span>
                </div>
                <span className="text-slate-500 text-xs font-medium uppercase tracking-wider">Camera is Turned Off</span>
              </div>
            ) : (
              <video
                ref={videoRef}
                autoPlay
                playsInline
                muted
                className="w-full h-full object-cover"
              />
            )}

            {/* Quick action buttons overlays */}
            <div className="absolute bottom-4 left-1/2 -translate-x-1/2 flex items-center space-x-3 bg-slate-900/85 backdrop-blur-md px-4 py-2 rounded-full border border-slate-800 shadow-xl opacity-90 hover:opacity-100 transition duration-200">
              {/* Mic Icon toggle */}
              <button
                type="button"
                onClick={() => setIsMuted(!isMuted)}
                className={`w-10 h-10 rounded-full flex items-center justify-center transition-all ${
                  isMuted 
                    ? "bg-rose-600 hover:bg-rose-500 text-white" 
                    : "bg-slate-800 hover:bg-slate-700 text-slate-100"
                } cursor-pointer active:scale-95`}
                title={isMuted ? "Unmute Mic" : "Mute Mic"}
              >
                {isMuted ? <MicOff className="w-4.5 h-4.5" /> : <Mic className="w-4.5 h-4.5" />}
              </button>

              {/* Cam Icon toggle */}
              <button
                type="button"
                onClick={() => setIsCamOff(!isCamOff)}
                className={`w-10 h-10 rounded-full flex items-center justify-center transition-all ${
                  isCamOff 
                    ? "bg-rose-600 hover:bg-rose-500 text-white" 
                    : "bg-slate-800 hover:bg-slate-700 text-slate-100"
                } cursor-pointer active:scale-95`}
                title={isCamOff ? "Turn Cam On" : "Turn Cam Off"}
              >
                {isCamOff ? <VideoOff className="w-4.5 h-4.5" /> : <Video className="w-4.5 h-4.5" />}
              </button>
            </div>
          </div>

          {/* User Display Info Form */}
          <div className="mt-6 space-y-4">
            <div>
              <label htmlFor="display-name-input" className="block text-slate-400 text-xs font-semibold uppercase tracking-wider mb-2">
                What's your name?
              </label>
              <input
                id="display-name-input"
                type="text"
                maxLength={20}
                placeholder="Enter display name"
                value={displayName}
                onChange={handleNameChange}
                className="w-full px-4 py-3 rounded-xl bg-slate-950 border border-slate-800 text-white placeholder-slate-600 focus:outline-none focus:border-indigo-500 font-medium transition"
              />
            </div>

            <div className="pt-2 text-center text-xs text-slate-500 leading-normal flex items-center justify-center gap-1.5">
              <span>Settings and video feeds verify natively before connection setup.</span>
            </div>
          </div>
        </div>
      </main>

      {/* Styled Footer Card */}
      <footer className="py-6 border-t border-slate-900 text-center text-slate-600 text-xs mt-auto">
        <p>© 2026 MeetSphere Inc. Powered by high-fidelity browser engines and intelligent AI grounding models.</p>
      </footer>
    </div>
  );
}
