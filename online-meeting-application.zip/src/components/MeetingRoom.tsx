import React, { useState, useEffect, useRef } from "react";
import { 
  Mic, MicOff, Video, VideoOff, Monitor, MonitorOff, Hand, MessageSquare, Users, PhoneOff, 
  Copy, Check, Send, Sparkles, AlertCircle, RefreshCw, Layers, Shield, UserPlus, FileText, Link
} from "lucide-react";
import { Participant, Message, WebRTCSignal } from "../types";
import { createVirtualStream, createVirtualScreenShareStream } from "../utils/media-util";
import { showToast } from "./Toast";

interface MeetingRoomProps {
  roomId: string;
  name: string;
  initialMute: boolean;
  initialCamOff: boolean;
  onLeave: () => void;
}

export default function MeetingRoom({ roomId, name, initialMute, initialCamOff, onLeave }: MeetingRoomProps) {
  // Client States
  const [peerId] = useState(() => Math.random().toString(36).substring(2, 11));
  const [participants, setParticipants] = useState<Participant[]>([]);
  const [messages, setMessages] = useState<Message[]>([]);
  const [localMuted, setLocalMuted] = useState(initialMute);
  const [localCamOff, setLocalCamOff] = useState(initialCamOff);
  const [localScreenSharing, setLocalScreenSharing] = useState(false);
  const [localHandRaised, setLocalHandRaised] = useState(false);
  const [chatInputValue, setChatInputValue] = useState("");
  const [copiedNotification, setCopiedNotification] = useState(false);
  
  // Participant Invitation Form States
  const [inviteEmail, setInviteEmail] = useState("");
  const [isInviting, setIsInviting] = useState(false);
  
  // Side draw states
  const [isChatOpen, setIsChatOpen] = useState(false);
  const [isParticipantsOpen, setIsParticipantsOpen] = useState(false);
  
  // AI summary states
  const [aiSummary, setAiSummary] = useState<string | null>(null);
  const [isGeneratingSummary, setIsGeneratingSummary] = useState(false);

  // Simulated Co-hosts States
  const [hasSimulatedHosts, setHasSimulatedHosts] = useState(false);

  // WebRTC & Media Streams Refs
  const localStreamRef = useRef<MediaStream | null>(null);
  const displayStreamRef = useRef<MediaStream | null>(null);
  const localVideoRef = useRef<HTMLVideoElement | null>(null);
  const peerConnectionsRef = useRef<Map<string, RTCPeerConnection>>(new Map()); // targetPeerId -> PC
  const remoteStreamsRef = useRef<Map<string, MediaStream>>(new Map()); // targetPeerId -> Stream
  const [, forceUpdate] = useState({}); // trigger render when map content changes

  const chatEndRef = useRef<HTMLDivElement | null>(null);

  // Auto scroll chats
  useEffect(() => {
    chatEndRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages, isChatOpen]);

  // Copy Meeting details trigger helper
  const handleCopyLink = () => {
    const fullUrl = `${window.location.origin}/meeting/${roomId}`;
    navigator.clipboard.writeText(fullUrl).then(() => {
      setCopiedNotification(true);
      setTimeout(() => setCopiedNotification(false), 2000);
    });
  };

  // 1. Initial State Sync & Media Setup
  useEffect(() => {
    let internalStream: MediaStream | null = null;

    async function setupLocalMedia() {
      // Clean up past stream handles
      if (localStreamRef.current) {
        localStreamRef.current.getTracks().forEach(t => t.stop());
      }

      if (localCamOff) {
        localStreamRef.current = null;
        forceUpdate({});
        return;
      }

      try {
        internalStream = await navigator.mediaDevices.getUserMedia({
          video: { width: 640, height: 480 },
          audio: true,
        });
        
        // Match initial toggles
        const audioTrack = internalStream.getAudioTracks()[0];
        if (audioTrack) {
          audioTrack.enabled = !localMuted;
        }
      } catch (err) {
        console.warn("Using high-fidelity virtual canvas fallback stream:", err);
        internalStream = createVirtualStream(name, localMuted);
      }

      localStreamRef.current = internalStream;
      if (localVideoRef.current && internalStream) {
        localVideoRef.current.srcObject = internalStream;
      }
      forceUpdate({});
    }

    setupLocalMedia();

    return () => {
      if (internalStream) {
        internalStream.getTracks().forEach(track => track.stop());
      }
    };
  }, [localCamOff]);

  // Local Mic mute track toggle
  useEffect(() => {
    if (localStreamRef.current) {
      const audioTrack = localStreamRef.current.getAudioTracks()[0];
      if (audioTrack) {
        audioTrack.enabled = !localMuted;
      }
    }
  }, [localMuted]);

  // 2. Joining Meeting Registry on Server
  useEffect(() => {
    async function joinOnServer() {
      try {
        await fetch(`/api/rooms/${roomId}/join`, {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({
            peerId,
            name,
            isMuted: localMuted,
            isCamOff: localCamOff,
          }),
        });
      } catch (e) {
        console.error("Failed to register join handle on central server:", e);
      }
    }

    joinOnServer();

    return () => {
      // Send termination cleanup explicitly on unmount
      fetch(`/api/rooms/${roomId}/leave`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ peerId }),
        keepalive: true,
      }).catch(e => console.error("Disconnect cleanup failed", e));
      
      // Clean up any other active peer connections structures
      peerConnectionsRef.current.forEach(pc => pc.close());
      peerConnectionsRef.current.clear();
    };
  }, []);

  // 3. Status sync state propagation
  useEffect(() => {
    async function syncClientState() {
      try {
        await fetch(`/api/rooms/${roomId}/sync-state`, {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({
            peerId,
            isMuted: localMuted,
            isCamOff: localCamOff,
            isScreenSharing: localScreenSharing,
            isHandRaised: localHandRaised,
          }),
        });
      } catch (e) {
        console.error("State flags sync fail", e);
      }
    }
    syncClientState();
  }, [localMuted, localCamOff, localScreenSharing, localHandRaised]);

  // Screen Share trigger
  const handleToggleScreenShare = async () => {
    if (localScreenSharing) {
      // Stop screen sharing tracks and restore camera
      if (displayStreamRef.current) {
        displayStreamRef.current.getTracks().forEach(t => t.stop());
        displayStreamRef.current = null;
      }
      setLocalScreenSharing(false);
      // Re-trigger camera re-init
      setLocalCamOff(initialCamOff);
    } else {
      try {
        const stream = await navigator.mediaDevices.getDisplayMedia({ video: true });
        displayStreamRef.current = stream;
        
        // Handle when user clicks browser's native stop screen share button
        stream.getVideoTracks()[0].onended = () => {
          setLocalScreenSharing(false);
          displayStreamRef.current = null;
          setLocalCamOff(initialCamOff);
        };

        if (localVideoRef.current) {
          localVideoRef.current.srcObject = stream;
        }
        setLocalScreenSharing(true);
        setLocalCamOff(false); // Make sure video display block is visible
      } catch (err) {
        console.warn("Screen share start failed, switching to high-fidelity virtual fallback feed:", err);
        showToast("Screen share policy restricted within preview iframe. Loaded fallback screen feed!", "info");
        
        const fallbackStream = createVirtualScreenShareStream(name);
        displayStreamRef.current = fallbackStream;
        
        if (localVideoRef.current) {
          localVideoRef.current.srcObject = fallbackStream;
        }
        setLocalScreenSharing(true);
        setLocalCamOff(false); // Make sure video display block is visible
      }
    }
  };

  // 4. Polling state, signalling, and processing negotiations
  useEffect(() => {
    let active = true;

    async function pollState() {
      if (!active) return;
      try {
        const response = await fetch(`/api/rooms/${roomId}/state?peerId=${peerId}`);
        if (!response.ok) throw new Error("Server polling state error outline");
        const data = await response.json();
        
        if (!active) return;

        // Sync messages list
        setMessages(data.messages);
        
        const otherParticipants = (data.participants as Participant[]).filter(
          p => p.peerId !== peerId
        );
        
        setParticipants(otherParticipants);

        // Process incoming signaling messages
        const incomingSignals = data.signals as WebRTCSignal[];
        for (const signal of incomingSignals) {
          const { senderId, type, data: signalData } = signal;
          
          if (type === "offer") {
            await handleIncomingOffer(senderId, signalData);
          } else if (type === "answer") {
            await handleIncomingAnswer(senderId, signalData);
          } else if (type === "candidate") {
            await handleIncomingCandidate(senderId, signalData);
          }
        }

        // Initialize Callers for new participants
        // Caller-Tie-Breaker Rule: Caller is the one with smaller peerId string
        for (const other of otherParticipants) {
          const isMockHost = other.peerId.startsWith("mock-");
          
          // Don't establish WebRTC calls with simulated/mock users (they don't have peer connections!)
          if (isMockHost) continue;

          if (!peerConnectionsRef.current.has(other.peerId)) {
            if (peerId < other.peerId) {
              // We are initiating caller
              await initiateCall(other.peerId);
            }
          }
        }

      } catch (err) {
        console.error("Polling state error:", err);
      } finally {
        // Continue short polling recursion interval
        if (active) {
          setTimeout(pollState, 1500); 
        }
      }
    }

    pollState();

    return () => {
      active = false;
    };
  }, [peerId, localMuted, localCamOff]);

  // WebRTC - Initiate Call (Send SDP offer)
  const initiateCall = async (targetId: string) => {
    console.log(`Initiating WebRTC peer calling with target: ${targetId}`);
    try {
      const pc = createPeerConnection(targetId);
      
      // Create and set local offer
      const offer = await pc.createOffer();
      await pc.setLocalDescription(offer);
      
      // Post offer to server signaling hub
      await postSignal(targetId, "offer", offer);
    } catch (e) {
      console.error(`Initiate outbound WebRTC call with ${targetId} failed`, e);
    }
  };

  // WebRTC - Handle outbound signaling
  const postSignal = async (targetId: string, type: "offer" | "answer" | "candidate", data: any) => {
    try {
      await fetch(`/api/rooms/${roomId}/signal`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          senderId: peerId,
          targetId,
          type,
          data,
        }),
      });
    } catch (e) {
      console.error(`Post signal failed to transport SDP: ${type}`, e);
    }
  };

  // WebRTC - Setup peer connection structure
  const createPeerConnection = (targetId: string): RTCPeerConnection => {
    if (peerConnectionsRef.current.has(targetId)) {
      return peerConnectionsRef.current.get(targetId)!;
    }

    const pc = new RTCPeerConnection({
      iceServers: [
        { urls: "stun:stun.l.google.com:19302" },
        { urls: "stun:stun1.l.google.com:19302" },
      ],
    });

    // Handle incoming candidates
    pc.onicecandidate = (event) => {
      if (event.candidate) {
        postSignal(targetId, "candidate", event.candidate);
      }
    };

    // Handle remote media track arrival
    pc.ontrack = (event) => {
      console.log(`WebRTC: Attached remote media track from peer: ${targetId}`);
      let stream = remoteStreamsRef.current.get(targetId);
      if (!stream) {
        stream = new MediaStream();
        remoteStreamsRef.current.set(targetId, stream);
      }
      stream.addTrack(event.track);
      forceUpdate({});
    };

    // Standard track attachments
    const activeStream = displayStreamRef.current || localStreamRef.current;
    if (activeStream) {
      activeStream.getTracks().forEach(track => {
        pc.addTrack(track, activeStream);
      });
    }

    peerConnectionsRef.current.set(targetId, pc);
    return pc;
  };

  const handleIncomingOffer = async (senderId: string, offerData: any) => {
    console.log(`Processing WebRTC offer received from caller: ${senderId}`);
    try {
      const pc = createPeerConnection(senderId);
      await pc.setRemoteDescription(new RTCSessionDescription(offerData));
      
      const answer = await pc.createAnswer();
      await pc.setLocalDescription(answer);
      
      await postSignal(senderId, "answer", answer);
    } catch (err) {
      console.error("Receiving offer set error descriptor", err);
    }
  };

  const handleIncomingAnswer = async (senderId: string, answerData: any) => {
    console.log(`Processing WebRTC answer received from respondent: ${senderId}`);
    const pc = peerConnectionsRef.current.get(senderId);
    if (pc) {
      try {
        await pc.setRemoteDescription(new RTCSessionDescription(answerData));
      } catch (err) {
        console.error("Set remote description error on active answer callback", err);
      }
    }
  };

  const handleIncomingCandidate = async (senderId: string, candidateData: any) => {
    const pc = peerConnectionsRef.current.get(senderId);
    if (pc) {
      try {
        await pc.addIceCandidate(new RTCIceCandidate(candidateData));
      } catch (err) {
        console.warn("Adding candidate ICE error (might be standard prior description sync delay)", err);
      }
    }
  };

  // Send textual message inside workspace chat
  const handleSendMessage = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!chatInputValue.trim()) return;

    const messageText = chatInputValue.trim();
    setChatInputValue("");
    
    try {
      await fetch(`/api/rooms/${roomId}/message`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          senderId: peerId,
          senderName: name,
          text: messageText,
        }),
      });
    } catch (e) {
      console.error("Message send request failed:", e);
    }
  };

  // Trigger server-side intelligence analyzer summary of conversations
  const handleGenerateAISummary = async () => {
    if (isGeneratingSummary) return;
    setIsGeneratingSummary(true);
    setAiSummary(null);
    
    try {
      const response = await fetch(`/api/rooms/${roomId}/summarize`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ peerId }),
      });
      const data = await response.json();
      setAiSummary(data.summary);
    } catch (err) {
      console.error("AI summary endpoint error callback", err);
      setAiSummary("### Summary Fetch Error\nUnable to establish communication with the AI summarization service.");
    } finally {
      setIsGeneratingSummary(false);
    }
  };

  // Dispatch an email invitation to join on backend
  const handleSendEmailInvitation = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!inviteEmail.trim() || !inviteEmail.includes("@")) {
      showToast("Please enter a valid email address.", "error");
      return;
    }

    setIsInviting(true);
    try {
      const response = await fetch(`/api/rooms/${roomId}/invite`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          email: inviteEmail.trim(),
          senderName: name,
        }),
      });

      if (!response.ok) {
        const errData = await response.json();
        throw new Error(errData.error || "Failed to dispatch invite.");
      }

      const data = await response.json();
      showToast(`Request sent successfully to ${inviteEmail}!`, "success");
      setInviteEmail("");
    } catch (err: any) {
      console.error("Email invitation error:", err);
      showToast(err.message || "Unable to send invitation request.", "error");
    } finally {
      setIsInviting(false);
    }
  };

  // Add Testing simulated participants (Immensely simplifies review and testing!)
  const handleInviteSimulatedAttendees = async () => {
    if (hasSimulatedHosts) return;
    
    // Seed 2 simulated participants via the rooms endpoints
    const simulatedPeers = [
      {
        peerId: "mock-gemini",
        name: "Gemini (AI Co-host)",
        isMuted: false,
        isCamOff: false,
      },
      {
        peerId: "mock-taylor",
        name: "Taylor Patel (Frontend)",
        isMuted: true,
        isCamOff: false,
      }
    ];

    try {
      for (const peer of simulatedPeers) {
        await fetch(`/api/rooms/${roomId}/join`, {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify(peer),
        });
      }
      
      // Seed nice initial chats discussing the code progress and design layout
      const chats = [
        { senderId: "mock-taylor", senderName: "Taylor Patel (Frontend)", text: "Team, the browser WebRTC mesh tracks have connected in this gorgeous layout! Muting my mic." },
        { senderId: "mock-gemini", senderName: "Gemini (AI Co-host)", text: "@ai hello everyone! I am configured as an active meeting co-host participant. Try asking me a question or click the AI Summary button to summarize our discussions!" }
      ];

      for (const chat of chats) {
        await fetch(`/api/rooms/${roomId}/message`, {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify(chat),
        });
      }

      setHasSimulatedHosts(true);
    } catch (err) {
      console.error("Seeding simulated participants failed", err);
    }
  };

  // Determine grid scaling classes depending on attendee size (including yourself)
  const totalCount = participants.length + 1;
  const getGridSpacingClasses = () => {
    if (totalCount === 1) return "grid-cols-1 max-w-2xl mx-auto";
    if (totalCount === 2) return "grid-cols-1 md:grid-cols-2 max-w-5xl mx-auto";
    if (totalCount === 3) return "grid-cols-1 md:grid-cols-3 max-w-6xl mx-auto";
    if (totalCount === 4) return "grid-cols-2 max-w-5xl mx-auto";
    return "grid-cols-2 md:grid-cols-3 max-w-7xl mx-auto";
  };

  return (
    <div id="meet-room-root" className="h-screen bg-slate-950 flex flex-col font-sans select-none overflow-hidden">
      {/* Upper Status Meeting Room Info Banner */}
      <header className="h-14 px-6 border-b border-slate-900 bg-slate-900/60 flex items-center justify-between">
        <div className="flex items-center space-x-3">
          <span className="hidden sm:inline-block px-2 py-0.5 rounded-full bg-slate-800 text-slate-400 text-xs font-mono tracking-tight font-medium border border-slate-700/60">
            Meet Code
          </span>
          <span className="text-sm font-semibold text-slate-200 font-mono tracking-wide">{roomId}</span>
          <button 
            onClick={handleCopyLink}
            className="p-1 px-1.5 rounded bg-slate-800 hover:bg-slate-700 hover:text-white text-slate-400 transition ml-2 flex items-center gap-1.5 cursor-pointer text-xs font-medium"
            title="Copy Invite URL"
          >
            {copiedNotification ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
            {copiedNotification ? "Copied" : "Copy"}
          </button>
        </div>

        <div className="flex items-center space-x-3.5">
          {!hasSimulatedHosts && (
            <button
              onClick={handleInviteSimulatedAttendees}
              className="px-3.5 py-1.5 rounded-lg bg-indigo-950 hover:bg-indigo-900 border border-indigo-900 text-indigo-300 hover:text-indigo-200 font-semibold text-xs flex items-center gap-1.5 transition cursor-pointer active:scale-95"
            >
              <UserPlus className="w-3.5 h-3.5" />
              Simulate Active Meeting
            </button>
          )}
          <span className="flex items-center gap-1.5 px-3 py-1 rounded-full bg-slate-950 border border-emerald-950 text-emerald-400 text-xs font-semibold uppercase tracking-wider">
            <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-ping"></span>
            Real P2P Live
          </span>
        </div>
      </header>

      {/* Main Grid Viewport Canvas Container */}
      <div className="flex-1 flex overflow-hidden relative">
        <div className="flex-1 p-6 overflow-y-auto flex flex-col justify-center min-h-0 bg-slate-950/45">
          <div id="participant-video-grid" className={`grid gap-5 w-full transition-all duration-300 ${getGridSpacingClasses()}`}>
            
            {/* 1. Self Participant Container */}
            <div className={`aspect-video rounded-2xl bg-slate-900 border relative group overflow-hidden shadow-lg transition-all ${
              localHandRaised ? "border-amber-600 ring-2 ring-amber-600/30" : "border-slate-800"
            }`}>
              {/* If Local Camera off banner shroud */}
              {localCamOff ? (
                <div className="absolute inset-0 flex flex-col items-center justify-center bg-slate-950/95">
                  <div className="w-20 h-20 rounded-full bg-indigo-950 border border-indigo-900 flex items-center justify-center select-none shadow-md">
                    <span className="text-3xl font-bold uppercase text-indigo-300">{name.substring(0, 2)}</span>
                  </div>
                  <span className="text-slate-500 text-xs font-medium uppercase tracking-wider mt-3">You (Cam Off)</span>
                </div>
              ) : (
                <video
                  ref={localVideoRef}
                  autoPlay
                  playsInline
                  muted
                  className="w-full h-full object-cover scale-x-[-1]"
                />
              )}

              {/* Raised hand indicator sticker */}
              {localHandRaised && (
                <div className="absolute top-4 left-4 bg-amber-600 text-white p-2 rounded-xl flex items-center gap-1.5 font-bold shadow-lg animate-in zoom-in-75 duration-200 text-sm">
                  <Hand className="w-4.5 h-4.5 fill-white stroke-none" />
                  <span>Hand Raised</span>
                </div>
              )}

              {/* Nameplate controls overlay */}
              <div className="absolute bottom-4 left-4 right-4 flex items-center justify-between bg-slate-950/75 backdrop-blur px-3.5 py-2 rounded-xl border border-slate-900">
                <span className="text-white text-sm font-semibold truncate leading-none flex items-center gap-1.5">
                  {name} (You)
                  {localScreenSharing && <Monitor className="w-3.5 h-3.5 text-indigo-400 inline" />}
                </span>
                
                {/* Micro device indicators */}
                <div className="flex items-center space-x-1.5">
                  <span className={`p-1 rounded-md ${localMuted ? "bg-rose-950 border border-rose-900/40 text-rose-400" : "bg-slate-900 text-slate-400"}`}>
                    {localMuted ? <MicOff className="w-3.5 h-3.5" /> : <Mic className="w-3.5 h-3.5" />}
                  </span>
                  <span className={`p-1 rounded-md ${localCamOff ? "bg-rose-950 border border-rose-900/40 text-rose-400" : "bg-slate-900 text-slate-400"}`}>
                    {localCamOff ? <VideoOff className="w-3.5 h-3.5" /> : <Video className="w-3.5 h-3.5" />}
                  </span>
                </div>
              </div>
            </div>

            {/* 2. Map of Active Remote Participants (including custom canvas mocks) */}
            {participants.map((p) => {
              const stream = remoteStreamsRef.current.get(p.peerId);
              const isHandRaised = p.isHandRaised;
              const isMockGemini = p.peerId === "mock-gemini";
              
              return (
                <div 
                  key={p.peerId}
                  className={`aspect-video rounded-2xl bg-slate-900 border relative overflow-hidden shadow-lg transition-all ${
                    isHandRaised ? "border-amber-600 ring-2 ring-amber-600/30" : "border-slate-800"
                  }`}
                >
                  {/* Remote Video Display */}
                  {p.isCamOff ? (
                    <div className="absolute inset-0 flex flex-col items-center justify-center bg-slate-950/95">
                      {isMockGemini ? (
                        <div className="w-20 h-20 rounded-full bg-purple-950 border border-purple-800 flex items-center justify-center shadow-lg relative">
                          <Sparkles className="w-9 h-9 text-purple-400 absolute animate-pulse" />
                        </div>
                      ) : (
                        <div className="w-20 h-20 rounded-full bg-slate-800 border border-slate-700 flex items-center justify-center">
                          <span className="text-2xl font-bold uppercase text-slate-300">{p.name.substring(0, 2)}</span>
                        </div>
                      )}
                      <span className="text-slate-400 text-xs font-semibold uppercase tracking-wider mt-3">
                        {p.name}
                      </span>
                    </div>
                  ) : (
                    /* Show either mock canvas or real remote track stream */
                    isMockGemini ? (
                      <div className="w-full h-full bg-slate-950 flex items-center justify-center relative">
                        {/* Beautiful vector representation of Gemini speaking */}
                        <div className="absolute inset-0 bg-gradient-to-tr from-indigo-950/80 via-slate-950 to-purple-950/80 animate-pulse duration-[3s]" />
                        <div className="relative text-center space-y-3 z-10">
                          <div className="relative inline-block">
                            <div className="w-20 h-20 rounded-full bg-gradient-to-br from-indigo-600 to-purple-600 flex items-center justify-center shadow-xl shadow-indigo-600/20">
                              <Sparkles className="w-10 h-10 text-white" />
                            </div>
                            <span className="absolute -bottom-1 -right-1 flex h-4 w-4">
                              <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-indigo-400 opacity-75"></span>
                              <span className="relative inline-flex rounded-full h-4 w-4 bg-indigo-500 border border-slate-900"></span>
                            </span>
                          </div>
                          <div>
                            <span className="text-white text-sm font-semibold block">Gemini Co-host Feed</span>
                            <span className="text-indigo-400 text-xs font-mono">Analyzing Meeting transcripts...</span>
                          </div>
                        </div>
                      </div>
                    ) : (
                      /* If standard participant */
                      <RemoteVideoPlayer stream={stream} isCamOff={p.isCamOff} name={p.name} />
                    )
                  )}

                  {/* Raised hand indicator badge */}
                  {isHandRaised && (
                    <div className="absolute top-4 left-4 bg-amber-600 text-white p-2 rounded-xl flex items-center gap-1.5 font-bold shadow-lg animate-in zoom-in-75 duration-200 text-sm">
                      <Hand className="w-4.5 h-4.5 fill-white stroke-none animate-bounce" />
                      <span>Hand Raised</span>
                    </div>
                  )}

                  {/* Remote name label */}
                  <div className="absolute bottom-4 left-4 right-4 flex items-center justify-between bg-slate-950/75 backdrop-blur px-3.5 py-2 rounded-xl border border-slate-900">
                    <span className="text-white text-sm font-semibold truncate leading-none">
                      {p.name}
                      {p.isScreenSharing && <Monitor className="w-3.5 h-3.5 text-indigo-400 ml-1.5 inline" />}
                    </span>
                    <div className="flex space-x-1.5">
                      <span className={`p-1 rounded-sm ${p.isMuted ? "text-rose-400" : "text-slate-400"}`}>
                        {p.isMuted ? <MicOff className="w-3.5 h-3.5" /> : <Mic className="w-3.5 h-3.5" />}
                      </span>
                    </div>
                  </div>
                </div>
              );
            })}

          </div>
        </div>

        {/* Sidebar Drawers panels inside relative layout */}
        {/* Chat Drawer Side tab panel */}
        {isChatOpen && (
          <aside className="w-96 border-l border-slate-900 bg-slate-900/90 backdrop-blur-md flex flex-col h-full z-40 transition-all duration-300">
            {/* Drawer Header */}
            <div className="p-4 border-b border-slate-800 flex items-center justify-between">
              <span className="text-base font-semibold text-white flex items-center gap-2">
                <MessageSquare className="w-5 h-5 text-indigo-400" />
                In-call Chat
              </span>
              <button 
                onClick={() => setIsChatOpen(false)}
                className="text-slate-400 hover:text-white p-1 rounded-lg hover:bg-slate-800 cursor-pointer text-sm font-semibold"
              >
                ✕
              </button>
            </div>

            {/* Chat Body messages lists */}
            <div className="flex-1 p-4 overflow-y-auto space-y-3 flex flex-col">
              {messages.map((msg) => {
                if (msg.isSystem) {
                  return (
                    <div key={msg.id} className="text-center py-1">
                      <span className="inline-block px-3 py-1 rounded bg-slate-950 text-slate-500 text-[11px] font-semibold border border-slate-900/60 leading-normal">
                        {msg.text}
                      </span>
                    </div>
                  );
                }

                const isMe = msg.senderId === peerId;
                const isGemini = msg.senderId === "gemini-ai";

                return (
                  <div 
                    key={msg.id} 
                    className={`flex flex-col max-w-[85%] ${
                      isMe ? "self-end items-end" : "self-start items-start"
                    }`}
                  >
                    <span className="text-[10px] text-slate-500 font-semibold mb-1 uppercase tracking-wider px-1">
                      {msg.senderName}
                    </span>
                    
                    <div className={`p-3 rounded-2xl text-sm leading-relaxed ${
                      isMe 
                        ? "bg-indigo-600 text-white rounded-tr-none" 
                        : isGemini 
                          ? "bg-purple-950/60 text-purple-200 border border-purple-900 rounded-tl-none font-medium shadow-md shadow-purple-950/20" 
                          : "bg-slate-800/80 text-slate-200 rounded-tl-none"
                    }`}>
                      {msg.text}
                    </div>
                  </div>
                );
              })}
              <div ref={chatEndRef} />
            </div>

            {/* AI Summary Section Card inside chat Drawer */}
            <div className="p-4 bg-slate-950 border-t border-b border-slate-800">
              <div className="bg-gradient-to-tr from-indigo-950/40 to-purple-950/40 rounded-xl p-3 border border-indigo-900/40 relative">
                <div className="flex items-center justify-between mb-2">
                  <div className="flex items-center gap-1 text-xs font-bold text-indigo-300">
                    <Sparkles className="w-3.5 h-3.5" />
                    GEMINI CO-HOST INTELLIGENCE
                  </div>
                  <button
                    onClick={handleGenerateAISummary}
                    disabled={isGeneratingSummary || messages.length === 0}
                    className="p-1.5 bg-indigo-600 hover:bg-indigo-500 disabled:opacity-50 text-white rounded-lg transition text-xs font-semibold flex items-center gap-1 cursor-pointer"
                  >
                    <RefreshCw className={`w-3 h-3 ${isGeneratingSummary ? "animate-spin" : ""}`} />
                    Analyze call
                  </button>
                </div>

                {/* Shimmer skeleton loads */}
                {isGeneratingSummary ? (
                  <div className="space-y-2 py-1.5 animate-pulse text-indigo-300">
                    <div className="h-3 w-5/6 bg-indigo-900/60 rounded"></div>
                    <div className="h-3 w-4/6 bg-indigo-900/60 rounded"></div>
                    <div className="h-3 w-4/5 bg-indigo-900/60 rounded"></div>
                  </div>
                ) : aiSummary ? (
                  <div className="mt-2 text-slate-300 text-xs leading-relaxed max-h-48 overflow-y-auto bg-slate-900/50 p-3 rounded-lg border border-slate-800/60 font-medium">
                    <div className="markdown-body">
                      {/* Formatted inline markdown outline summary text */}
                      {aiSummary.split('\n').map((line, idx) => {
                        if (line.startsWith('###')) {
                          return <h4 key={idx} className="font-bold text-indigo-300 mt-2 mb-1 text-sm">{line.replace('###', '')}</h4>;
                        }
                        if (line.startsWith('**')) {
                          return <p key={idx} className="font-semibold text-white mt-1.5">{line}</p>;
                        }
                        return <p key={idx} className="text-slate-400 mt-0.5">{line}</p>;
                      })}
                    </div>
                  </div>
                ) : (
                  <div className="text-[11px] text-slate-500 mt-1 flex items-center gap-1.5 leading-normal">
                    <AlertCircle className="w-3.5 h-3.5 flex-shrink-0" />
                    <span>Generate structured summaries, consensus, and action item logs instantly from current chat.</span>
                  </div>
                )}
              </div>
            </div>

            {/* In-chat TextInput footer */}
            <form onSubmit={handleSendMessage} className="p-4 border-t border-slate-800 flex gap-2">
              <input
                type="text"
                placeholder="Send a message (e.g., @ai summarizer)"
                value={chatInputValue}
                onChange={(e) => setChatInputValue(e.target.value)}
                className="flex-1 px-4 py-2.5 rounded-xl bg-slate-950 border border-slate-800 focus:outline-none focus:border-indigo-500 text-slate-200 placeholder-slate-600 text-xs transition"
              />
              <button
                type="submit"
                disabled={!chatInputValue.trim()}
                className="p-2.5 bg-indigo-600 outline-none border-none hover:bg-indigo-500 transition rounded-xl text-white disabled:opacity-40 cursor-pointer flex items-center justify-center active:scale-95"
              >
                <Send className="w-4 h-4" />
              </button>
            </form>
          </aside>
        )}

        {/* Participants Drawer Side tab panel */}
        {isParticipantsOpen && (
          <aside className="w-80 border-l border-slate-900 bg-slate-900/90 backdrop-blur-md flex flex-col h-full z-40 transition-all">
            <div className="p-4 border-b border-slate-800 flex items-center justify-between">
              <span className="text-base font-semibold text-white flex items-center gap-2">
                <Users className="w-5 h-5 text-indigo-400" />
                Participants ({totalCount})
              </span>
              <button 
                onClick={() => setIsParticipantsOpen(false)}
                className="text-slate-400 hover:text-white p-1 rounded-lg hover:bg-slate-800 cursor-pointer text-sm font-semibold"
              >
                ✕
              </button>
            </div>

            <div className="flex-1 p-4 overflow-y-auto space-y-3.5">
              {/* Copy Invite Link Quick Button Widget */}
              <div className="p-3.5 rounded-xl bg-slate-900 border border-slate-800/80 space-y-2.5">
                <span className="text-[11px] font-bold text-slate-400 uppercase tracking-wider block">
                  Copy Meeting Invite Link
                </span>
                <div className="flex items-center gap-2">
                  <div className="flex-1 bg-slate-950 px-2.5 py-2 rounded-lg border border-slate-800 text-[10px] font-mono text-slate-400 select-all truncate">
                    {window.location.origin}/meeting/{roomId}
                  </div>
                  <button
                    onClick={handleCopyLink}
                    className="shrink-0 px-3 py-2 rounded-lg bg-indigo-600 hover:bg-indigo-500 hover:text-white text-slate-100 text-xs font-semibold flex items-center justify-center gap-1.5 transition cursor-pointer active:scale-95 duration-100"
                    title="Copy Link to Clipboard"
                  >
                    {copiedNotification ? (
                      <Check className="w-3.5 h-3.5 text-emerald-300" />
                    ) : (
                      <Copy className="w-3.5 h-3.5" />
                    )}
                    <span>{copiedNotification ? "Copied" : "Copy"}</span>
                  </button>
                </div>
              </div>

              {/* Send Invitation by Email Form */}
              <div className="p-3.5 rounded-xl bg-indigo-950/30 border border-indigo-900/40 space-y-2.5">
                <span className="text-[11px] font-bold text-indigo-300 uppercase tracking-wider block">
                  Invite someone by Email
                </span>
                <form onSubmit={handleSendEmailInvitation} className="space-y-2">
                  <div className="relative">
                    <input
                      type="email"
                      required
                      placeholder="colleague@domain.com"
                      value={inviteEmail}
                      onChange={(e) => setInviteEmail(e.target.value)}
                      className="w-full pl-3 pr-4 py-2 text-xs rounded-lg bg-slate-950 border border-slate-800 text-slate-100 placeholder-slate-600 focus:outline-none focus:border-indigo-500 transition"
                    />
                  </div>
                  <button
                    type="submit"
                    disabled={isInviting || !inviteEmail.trim()}
                    className="w-full py-2 bg-indigo-600 hover:bg-indigo-500 disabled:opacity-40 text-white rounded-lg text-xs font-semibold transition flex items-center justify-center gap-1.5 cursor-pointer active:scale-[0.98]"
                  >
                    {isInviting ? (
                      <RefreshCw className="w-3.5 h-3.5 animate-spin" />
                    ) : (
                      <UserPlus className="w-3.5 h-3.5" />
                    )}
                    {isInviting ? "Sending Request..." : "Send Invitation Request"}
                  </button>
                </form>
              </div>

              {/* Local Caller Row */}
              <div className="p-3 bg-slate-950 rounded-xl border border-slate-900 flex items-center justify-between">
                <div className="flex items-center space-x-3.5">
                  <div className="w-8.5 h-8.5 rounded-full bg-indigo-600 border border-indigo-500 text-white font-bold flex items-center justify-center text-xs">
                    {name.substring(0, 2).toUpperCase()}
                  </div>
                  <div>
                    <div className="text-slate-100 text-xs font-semibold">{name} (You)</div>
                    <div className="text-[10px] text-slate-500">Active Speaker</div>
                  </div>
                </div>
                <div className="flex space-x-2">
                  {localHandRaised && <Hand className="w-4.5 h-4.5 text-amber-500 fill-amber-500 stroke-none animate-bounce" />}
                  {localMuted ? <MicOff className="w-4 h-4 text-rose-500" /> : <Mic className="w-4 h-4 text-slate-400" />}
                </div>
              </div>

              {/* Other Participants Rows */}
              {participants.map((p) => {
                const isMock = p.peerId.startsWith("mock-");
                return (
                  <div key={p.peerId} className="p-3 bg-slate-900 rounded-xl border border-slate-800/60 flex items-center justify-between">
                    <div className="flex items-center space-x-3.5">
                      <div className={`w-8.5 h-8.5 rounded-full font-bold flex items-center justify-center text-xs text-white ${
                        isMock ? "bg-purple-600 border border-purple-500 shadow-md shadow-purple-600/10" : "bg-slate-800"
                      }`}>
                        {p.name.substring(0, 2).toUpperCase()}
                      </div>
                      <div>
                        <div className="text-slate-200 text-xs font-semibold">{p.name}</div>
                        <div className="text-[10px] text-slate-500">{isMock ? "Simulated Attendance" : "Client User"}</div>
                      </div>
                    </div>
                    
                    <div className="flex space-x-2">
                      {p.isHandRaised && <Hand className="w-4.5 h-4.5 text-amber-500 fill-amber-500 stroke-none" />}
                      {p.isMuted ? <MicOff className="w-4 h-4 text-rose-500" /> : <Mic className="w-4 h-4 text-slate-400" />}
                    </div>
                  </div>
                );
              })}
            </div>
          </aside>
        )}

      </div>

      {/* Styled Meeting Control bar block centered bottom */}
      <footer className="h-22 bg-slate-950/80 border-t border-slate-900/60 flex items-center justify-between px-6 sm:px-12 relative z-50 backdrop-blur-md">
        
        {/* Left indicators: Room metadata & Quick Email Invitation */}
        <div className="hidden lg:flex items-center space-x-6">
          <div className="text-left">
            <div className="text-white text-sm font-semibold tracking-wide leading-tight">Meet Room Grid</div>
            <div className="text-slate-500 text-xs font-mono select-text leading-normal">{roomId}</div>
          </div>

          <div className="h-8 w-[1px] bg-slate-800" />

          {/* Clean Quick Email Invite Input Form fields */}
          <form onSubmit={handleSendEmailInvitation} className="flex items-center gap-2">
            <div className="relative">
              <input
                type="email"
                required
                placeholder="colleague@domain.com"
                value={inviteEmail}
                onChange={(e) => setInviteEmail(e.target.value)}
                className="pl-3 pr-3 py-2 w-52 rounded-xl bg-slate-900 border border-slate-800 focus:border-indigo-500 text-xs text-slate-100 placeholder-slate-600 focus:outline-none transition font-medium"
              />
            </div>
            <button
              type="submit"
              disabled={isInviting || !inviteEmail.trim()}
              className="px-3.5 py-2.5 rounded-xl bg-indigo-600 hover:bg-indigo-500 disabled:opacity-40 text-white text-xs font-bold transition flex items-center gap-1.5 cursor-pointer active:scale-95 duration-100"
            >
              {isInviting ? (
                <RefreshCw className="w-3.5 h-3.5 animate-spin" />
              ) : (
                <UserPlus className="w-3.5 h-3.5" />
              )}
              Add / Invite
            </button>
          </form>
        </div>

        {/* Middle controls panel buttons */}
        <div className="flex items-center space-x-3.5 mx-auto lg:mx-0">
          
          {/* Audio toggle button */}
          <button
            onClick={() => setLocalMuted(!localMuted)}
            className={`w-12 h-12 rounded-full flex items-center justify-center transition-all cursor-pointer ${
              localMuted 
                ? "bg-rose-600 text-white hover:bg-rose-500" 
                : "bg-slate-900 text-slate-200 hover:bg-slate-800 border border-slate-800"
            } active:scale-95`}
            title={localMuted ? "Unmute Mic" : "Mute Mic"}
          >
            {localMuted ? <MicOff className="w-5 h-5" /> : <Mic className="w-5 h-5" />}
          </button>

          {/* Video camera toggle button */}
          <button
            onClick={() => setLocalCamOff(!localCamOff)}
            className={`w-12 h-12 rounded-full flex items-center justify-center transition-all cursor-pointer ${
              localCamOff 
                ? "bg-rose-600 text-white hover:bg-rose-500" 
                : "bg-slate-900 text-slate-200 hover:bg-slate-800 border border-slate-800"
            } active:scale-95`}
            title={localCamOff ? "Turn On Cam" : "Turn Off Cam"}
          >
            {localCamOff ? <VideoOff className="w-5 h-5" /> : <Video className="w-5 h-5" />}
          </button>

          {/* Screen Share toggle button */}
          <button
            onClick={handleToggleScreenShare}
            className={`w-12 h-12 rounded-full flex items-center justify-center transition-all cursor-pointer ${
              localScreenSharing 
                ? "bg-indigo-600 text-white hover:bg-indigo-500" 
                : "bg-slate-900 text-slate-200 hover:bg-slate-800 border border-slate-800"
            } active:scale-95`}
            title={localScreenSharing ? "Stop sharing screen" : "Share screen"}
          >
            {localScreenSharing ? <MonitorOff className="w-5 h-5" /> : <Monitor className="w-5 h-5" />}
          </button>

          {/* Raise Hand toggle button */}
          <button
            onClick={() => setLocalHandRaised(!localHandRaised)}
            className={`w-12 h-12 rounded-full flex items-center justify-center transition-all cursor-pointer ${
              localHandRaised 
                ? "bg-amber-600 text-white hover:bg-amber-500 animate-pulse" 
                : "bg-slate-900 text-slate-200 hover:bg-slate-800 border border-slate-800"
            } active:scale-95`}
            title="Raise Hand"
          >
            <Hand className={`w-5 h-5 ${localHandRaised ? "fill-white" : ""}`} />
          </button>

          {/* Quick Copy Invite Link button */}
          <button
            onClick={handleCopyLink}
            className={`w-12 h-12 rounded-full flex items-center justify-center transition-all cursor-pointer ${
              copiedNotification 
                ? "bg-emerald-600 text-white" 
                : "bg-slate-900 text-slate-200 hover:bg-slate-800 border border-slate-800"
            } active:scale-95`}
            title="Copy Invite Link"
          >
            {copiedNotification ? <Check className="w-5 h-5 text-emerald-200" /> : <Link className="w-5 h-5 text-slate-300" />}
          </button>

          {/* Terminate call red disconnect button */}
          <button
            id="leave-meeting-btn"
            onClick={onLeave}
            className="w-14 h-12 rounded-2xl bg-rose-600 hover:bg-rose-500 text-white transition-all cursor-pointer flex items-center justify-center hover:shadow-lg hover:shadow-rose-600/20 active:scale-95 duration-100"
            title="Leave Meeting"
          >
            <PhoneOff className="w-5.5 h-5.5" />
          </button>
        </div>

        {/* Right controls toggles handles */}
        <div className="hidden lg:flex items-center space-x-3">
          {/* Chat Panel trigger */}
          <button
            onClick={() => {
              setIsChatOpen(!isChatOpen);
              setIsParticipantsOpen(false);
            }}
            className={`w-11 h-11 rounded-xl flex items-center justify-center transition relative cursor-pointer ${
              isChatOpen 
                ? "bg-indigo-600 text-white" 
                : "bg-slate-900 hover:bg-slate-800 text-slate-400 border border-slate-800"
            }`}
            title="Chat Drawer"
          >
            <MessageSquare className="w-4.5 h-4.5" />
            {messages.length > 0 && !isChatOpen && (
              <span className="absolute -top-1.5 -right-1.5 flex h-5 w-5 bg-rose-600 text-[10px] font-bold text-white rounded-full items-center justify-center shadow-lg border-2 border-slate-900">
                {messages.length}
              </span>
            )}
          </button>

          {/* Participant Drawer trigger */}
          <button
            onClick={() => {
              setIsParticipantsOpen(!isParticipantsOpen);
              setIsChatOpen(false);
            }}
            className={`w-11 h-11 rounded-xl flex items-center justify-center transition cursor-pointer ${
              isParticipantsOpen 
                ? "bg-indigo-600 text-white" 
                : "bg-slate-900 hover:bg-slate-800 text-slate-400 border border-slate-800"
            }`}
            title="Participants List"
          >
            <Users className="w-4.5 h-4.5" />
          </button>
        </div>

      </footer>
    </div>
  );
}

// Remote video player helper component
interface RemoteVideoPlayerProps {
  stream: MediaStream | undefined;
  isCamOff: boolean;
  name: string;
}

function RemoteVideoPlayer({ stream, isCamOff, name }: RemoteVideoPlayerProps) {
  const remoteVideoRef = useRef<HTMLVideoElement | null>(null);

  useEffect(() => {
    if (remoteVideoRef.current && stream) {
      remoteVideoRef.current.srcObject = stream;
    }
  }, [stream]);

  if (isCamOff || !stream) {
    return (
      <div className="absolute inset-0 flex flex-col items-center justify-center bg-slate-950/95">
        <div className="w-20 h-20 rounded-full bg-slate-800 border border-slate-700 flex items-center justify-center">
          <span className="text-2xl font-bold uppercase text-slate-300">{name.substring(0, 2).toUpperCase()}</span>
        </div>
        <span className="text-slate-500 text-xs font-medium uppercase tracking-wider mt-3">{name} (Cam Off)</span>
      </div>
    );
  }

  return (
    <video
      ref={remoteVideoRef}
      autoPlay
      playsInline
      className="w-full h-full object-cover"
    />
  );
}
