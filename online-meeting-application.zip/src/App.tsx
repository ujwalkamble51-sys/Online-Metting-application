import React, { useState, useEffect } from "react";
import LandingPage from "./components/LandingPage";
import MeetingRoom from "./components/MeetingRoom";
import { ToastContainer } from "./components/Toast"; // simple custom message notifications

export default function App() {
  const [currentView, setCurrentView] = useState<"landing" | "meeting">("landing");
  const [meetingId, setMeetingId] = useState("");
  const [userName, setUserName] = useState("");
  const [initialMute, setInitialMute] = useState(false);
  const [initialCamOff, setInitialCamOff] = useState(false);

  // URL meeting path parsing: support /meeting/abc-defg-hij or /abc-defg-hij
  useEffect(() => {
    const path = window.location.pathname;
    let roomIdFromUrl = "";
    
    if (path && path !== "/") {
      if (path.startsWith("/meeting/")) {
        roomIdFromUrl = path.replace("/meeting/", "");
      } else {
        roomIdFromUrl = path.replace("/", "");
      }
    }

    if (roomIdFromUrl) {
      // Clean and automatically decode code URL spaces
      const cleaned = decodeURIComponent(roomIdFromUrl).trim().toLowerCase();
      if (cleaned.length > 0) {
        setMeetingId(cleaned);
        // We stay on landing scene, but pre-populate the code input box!
      }
    }
  }, []);

  const handleJoinMeeting = (roomId: string, name: string, isMuted: boolean, isCamOff: boolean) => {
    setMeetingId(roomId);
    setUserName(name);
    setInitialMute(isMuted);
    setInitialCamOff(isCamOff);
    setCurrentView("meeting");
    
    // Update browser URL state cleanly without full reloading, resembling modern SPAs
    window.history.pushState({}, "", `/meeting/${roomId}`);
  };

  const handleLeaveMeeting = () => {
    setCurrentView("landing");
    // Clear URL location route back to root index
    window.history.pushState({}, "", "/");
  };

  return (
    <div id="application-root" className="min-h-screen bg-slate-950 font-sans antialiased text-slate-100">
      {currentView === "landing" ? (
        <LandingPage onJoinMeeting={handleJoinMeeting} />
      ) : (
        <MeetingRoom
          roomId={meetingId}
          name={userName}
          initialMute={initialMute}
          initialCamOff={initialCamOff}
          onLeave={handleLeaveMeeting}
        />
      )}
      <ToastContainer />
    </div>
  );
}
