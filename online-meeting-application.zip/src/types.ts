export interface Participant {
  peerId: string;
  name: string;
  joinedAt: number;
  lastSeen: number;
  isMuted: boolean;
  isCamOff: boolean;
  isScreenSharing: boolean;
  isHandRaised: boolean;
}

export interface Message {
  id: string;
  senderId: string;
  senderName: string;
  text: string;
  timestamp: number;
  isSystem: boolean;
}

export interface WebRTCSignal {
  senderId: string;
  type: "offer" | "answer" | "candidate";
  data: any;
}
