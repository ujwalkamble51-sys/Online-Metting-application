export function createVirtualStream(name: string, isMuted: boolean): MediaStream {
  const canvas = document.createElement("canvas");
  canvas.width = 640;
  canvas.height = 480;
  const ctx = canvas.getContext("2d");
  
  // Use HTMLCanvasElement.captureStream with fallback checks
  const stream = (canvas as any).captureStream ? (canvas as any).captureStream(30) : null;
  
  // Create an oscillator-based silent audio stream track on the container
  let audioTrack: MediaStreamTrack | null = null;
  try {
    const audioCtx = new (window.AudioContext || (window as any).webkitAudioContext)();
    const oscillator = audioCtx.createOscillator();
    const dst = audioCtx.createMediaStreamDestination();
    oscillator.connect(dst);
    oscillator.frequency.value = 440;
    oscillator.start();
    audioTrack = dst.stream.getAudioTracks()[0];
  } catch (e) {
    console.error("Audio fallback stream failed:", e);
  }

  // Draw code inside an interval
  let angle = 0;
  const timer = setInterval(() => {
    if (!ctx) return;
    
    // Draw background color gradients
    const grad = ctx.createRadialGradient(320, 240, 50, 320, 240, 320);
    grad.addColorStop(0, "#1e1b4b"); // indigo
    grad.addColorStop(1, "#030712"); // deep slate
    ctx.fillStyle = grad;
    ctx.fillRect(0, 0, 640, 480);
    
    // Ambient rotating glowing orbits
    ctx.strokeStyle = "rgba(99, 102, 241, 0.4)";
    ctx.lineWidth = 1.5;
    ctx.beginPath();
    ctx.arc(320, 240, 140, 0, Math.PI * 2);
    ctx.stroke();

    ctx.strokeStyle = "rgba(56, 189, 248, 0.5)";
    ctx.lineWidth = 3;
    ctx.beginPath();
    ctx.arc(320, 240, 100 + Math.sin(angle) * 12, 0, Math.PI * 2);
    ctx.stroke();
    
    ctx.strokeStyle = "rgba(168, 85, 247, 0.45)";
    ctx.lineWidth = 2;
    ctx.beginPath();
    ctx.arc(320, 240, 80 + Math.cos(angle * 1.5) * 16, 0, Math.PI * 2);
    ctx.stroke();

    // Initials background circle
    ctx.fillStyle = "#1e293b";
    ctx.strokeStyle = "#4f46e5";
    ctx.lineWidth = 4;
    ctx.beginPath();
    ctx.arc(320, 240, 52, 0, Math.PI * 2);
    ctx.fill();
    ctx.stroke();

    // Draw display name text inside circle
    ctx.fillStyle = "#ffffff";
    ctx.font = "bold 44px system-ui, sans-serif";
    ctx.textAlign = "center";
    ctx.textBaseline = "middle";
    ctx.fillText(name.substring(0, 2).toUpperCase(), 320, 240);
    
    // Display textual info at the bottom
    const textDesc = isMuted ? "🎤 Muted Fallback Stream" : "🎤 Virtual Mic Capturing";
    ctx.fillStyle = isMuted ? "#f43f5e" : "#10b981";
    ctx.font = "bold 13px monospace";
    ctx.fillText(textDesc, 320, 390);

    // Audio animation bars at the bottom
    if (!isMuted) {
      ctx.fillStyle = "#6366f1";
      for (let i = 0; i < 5; i++) {
        const barHeight = 6 + Math.abs(Math.sin(angle * 2.5 + i)) * 24;
        ctx.fillRect(270 + i * 20, 434 - barHeight, 10, barHeight);
      }
    } else {
      ctx.fillStyle = "#f43f5e";
      ctx.fillRect(290, 420, 60, 4);
    }
    
    angle += 0.05;
  }, 1000 / 25); // ~25 FPS
  
  const finalStream = new MediaStream();
  if (stream) {
    const videoTrack = stream.getVideoTracks()[0];
    if (videoTrack) {
      // Overwrite stop to make sure our canvas drawing interval is completely garbage collected
      const origStop = videoTrack.stop;
      videoTrack.stop = function() {
        clearInterval(timer);
        if (origStop) origStop.call(videoTrack);
      };
      finalStream.addTrack(videoTrack);
    }
  }
  if (audioTrack) {
    finalStream.addTrack(audioTrack);
  }
  
  return finalStream;
}

export function createVirtualScreenShareStream(senderName: string): MediaStream {
  const canvas = document.createElement("canvas");
  canvas.width = 1280;
  canvas.height = 720;
  const ctx = canvas.getContext("2d");
  
  const stream = (canvas as any).captureStream ? (canvas as any).captureStream(30) : null;
  
  let frame = 0;
  const timer = setInterval(() => {
    if (!ctx) return;
    
    // Background: elegant code IDE layout styling
    ctx.fillStyle = "#1e1e2e"; // Mocha editor slate
    ctx.fillRect(0, 0, 1280, 720);
    
    // Sidebar list
    ctx.fillStyle = "#181825";
    ctx.fillRect(0, 0, 240, 720);
    
    // Workspace code files list header
    ctx.fillStyle = "#cdd6f4";
    ctx.font = "bold 14px system-ui, sans-serif";
    ctx.textAlign = "left";
    ctx.fillText("EXPLORER", 24, 40);
    
    ctx.fillStyle = "#a6adc8";
    ctx.font = "13px monospace";
    ctx.fillText("🗀 src/components", 24, 80);
    ctx.fillText("  🖺 MeetingRoom.tsx", 24, 110);
    ctx.fillStyle = "#89b4fa"; // Highlight current file
    ctx.fillText("  🖺 ScreenShareFeed.ts", 24, 140);
    ctx.fillStyle = "#a6adc8";
    ctx.fillText("  🖺 App.tsx", 24, 170);
    ctx.fillText("🗀 server", 24, 200);
    ctx.fillText("  🖺 server.ts", 24, 230);
    
    // Drawing Tab headers
    ctx.fillStyle = "#11111b";
    ctx.fillRect(240, 0, 1040, 50);
    
    ctx.fillStyle = "#1e1e2e";
    ctx.fillRect(240, 10, 220, 40);
    ctx.fillStyle = "#f5c2e7"; // File text tabs colored accent
    ctx.fillRect(240, 47, 220, 3);
    
    ctx.fillStyle = "#cdd6f4";
    ctx.font = "bold 13px system-ui, sans-serif";
    ctx.fillText("ScreenShareFeed.ts", 260, 32);
    
    // Main editor pane line numbers
    ctx.fillStyle = "#585b70";
    ctx.font = "14px monospace";
    for (let i = 1; i <= 20; i++) {
      ctx.fillText(String(i).padStart(2, "0"), 260, 80 + i * 28);
    }
    
    // Simulated Code text blocks using syntax highlight properties
    ctx.fillStyle = "#f38ba8"; // keyword color
    ctx.fillText("import", 300, 108);
    ctx.fillStyle = "#cdd6f4";
    ctx.fillText("{ WebRTCConnection }", 360, 108);
    ctx.fillStyle = "#f38ba8";
    ctx.fillText("from", 520, 108);
    ctx.fillStyle = "#a6e3a1"; // string color
    ctx.fillText('"./connection";', 560, 108);
    
    ctx.fillStyle = "#f38ba8";
    ctx.fillText("const", 300, 136);
    ctx.fillStyle = "#f9e2af"; // variable
    ctx.fillText("activeMeetingPresenter", 350, 136);
    ctx.fillStyle = "#cdd6f4";
    ctx.fillText("= (", 540, 136);
    ctx.fillStyle = "#fab387";
    ctx.fillText("senderName", 565, 136);
    ctx.fillStyle = "#cdd6f4";
    ctx.fillText(`) => {`, 650, 136);
    
    ctx.fillStyle = "#89b4fa"; // Code comment color
    ctx.fillText(`// Success fallback screen share stream by ${senderName}`, 330, 164);
    
    ctx.fillStyle = "#f38ba8";
    ctx.fillText("  console", 300, 192);
    ctx.fillStyle = "#cdd6f4";
    ctx.fillText(".", 362, 192);
    ctx.fillStyle = "#89b4fa";
    ctx.fillText("log", 370, 192);
    ctx.fillStyle = "#cdd6f4";
    ctx.fillText(`(`, 394, 192);
    ctx.fillStyle = "#a6e3a1";
    ctx.fillText(`"Rendering high fidelity code presentation..."`, 402, 192);
    ctx.fillStyle = "#cdd6f4";
    ctx.fillText(`);`, 730, 192);
    
    // Animated running metrics widget on screen share overlay
    ctx.fillStyle = "#11111b";
    ctx.fillRect(800, 80, 440, 240);
    ctx.strokeStyle = "#4f46e5";
    ctx.lineWidth = 2;
    ctx.strokeRect(800, 80, 440, 240);
    
    ctx.fillStyle = "#ffffff";
    ctx.font = "bold 14px system-ui, sans-serif";
    ctx.fillText("Live System Performance Metrics", 820, 115);
    
    ctx.fillStyle = "#a6e3a1";
    ctx.font = "12px monospace";
    ctx.fillText(`FPS: 30.0 • Latency: 12ms • Network: EXCELLENT`, 820, 145);
    
    // Draw an animated signal sine wave on mock telemetry box
    ctx.strokeStyle = "#89b4fa";
    ctx.lineWidth = 3;
    ctx.beginPath();
    for (let x = 0; x <= 400; x += 5) {
      const y = 230 + Math.sin(frame * 0.15 + x * 0.05) * 35;
      if (x === 0) {
        ctx.moveTo(820 + x, y);
      } else {
        ctx.lineTo(820 + x, y);
      }
    }
    ctx.stroke();
    
    // Footing status line
    ctx.fillStyle = "#11111b";
    ctx.fillRect(0, 680, 1280, 40);
    ctx.fillStyle = "#89b4fa";
    ctx.font = "bold 12px system-ui, sans-serif";
    ctx.fillText(`🎥 SCREEN PRESENTED BY ${senderName.toUpperCase()} (IFRAME RESOLVED FALLBACK)`, 24, 706);
    
    frame += 1;
  }, 1000 / 30);
  
  const finalStream = new MediaStream();
  if (stream) {
    const videoTrack = stream.getVideoTracks()[0];
    if (videoTrack) {
      const origStop = videoTrack.stop;
      videoTrack.stop = function() {
        clearInterval(timer);
        if (origStop) origStop.call(videoTrack);
      };
      finalStream.addTrack(videoTrack);
    }
  }
  
  return finalStream;
}

